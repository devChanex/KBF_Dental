<?php
$hostname = "216.218.206.40";
$username = "kbfdenta_sysadmin";
$password = '$ysAdmin2022';  
$database = 'kbfdenta_sysdb';   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>  